import SearchMeal from "./components/search-meals";

function App() {
  return (
    <>
      <SearchMeal />
    </>
  );
}

export default App;
