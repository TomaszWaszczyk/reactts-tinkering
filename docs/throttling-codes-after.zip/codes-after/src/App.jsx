import TrackMouse from "./components/track-mouse";

function App() {
  return (
    <>
      <TrackMouse />
    </>
  );
}

export default App;
