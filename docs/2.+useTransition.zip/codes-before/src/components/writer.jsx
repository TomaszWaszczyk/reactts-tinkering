import { WriterContainer } from "./styled-elements";

const Writer = () => {
  return <WriterContainer>Codelicks Academy</WriterContainer>;
};

export default Writer;
