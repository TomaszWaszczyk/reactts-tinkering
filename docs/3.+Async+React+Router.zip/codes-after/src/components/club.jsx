import { MainHeading } from "./styled-elements";

const Club = () => {
  return <MainHeading>Club</MainHeading>;
};

export default Club;
